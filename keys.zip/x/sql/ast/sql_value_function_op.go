package ast

type SQLValueFunctionOp uint

func (n *SQLValueFunctionOp) Pos() int {
	return 0
}
