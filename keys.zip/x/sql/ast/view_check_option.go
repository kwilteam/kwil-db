package ast

type ViewCheckOption uint

func (n *ViewCheckOption) Pos() int {
	return 0
}
