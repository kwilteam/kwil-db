package ast

type Node interface {
	Pos() int
}
