package ast

type FunctionParameterMode uint

func (n *FunctionParameterMode) Pos() int {
	return 0
}
