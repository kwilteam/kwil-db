package ast

type CheckPointStmt struct {
}

func (n *CheckPointStmt) Pos() int {
	return 0
}
