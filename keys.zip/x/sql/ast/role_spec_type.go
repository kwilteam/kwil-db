package ast

type RoleSpecType uint

func (n *RoleSpecType) Pos() int {
	return 0
}
