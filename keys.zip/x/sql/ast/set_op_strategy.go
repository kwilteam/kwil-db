package ast

type SetOpStrategy uint

func (n *SetOpStrategy) Pos() int {
	return 0
}
