package ast

type DiscardMode uint

func (n *DiscardMode) Pos() int {
	return 0
}
