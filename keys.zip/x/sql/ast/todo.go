package ast

type TODO struct {
}

func (n *TODO) Pos() int {
	return 0
}
