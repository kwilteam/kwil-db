package ast

type MinMaxOp uint

func (n *MinMaxOp) Pos() int {
	return 0
}
