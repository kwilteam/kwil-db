package ast

type DropBehavior uint

func (n *DropBehavior) Pos() int {
	return 0
}
