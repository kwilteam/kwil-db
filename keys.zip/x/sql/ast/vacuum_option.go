package ast

type VacuumOption uint

func (n *VacuumOption) Pos() int {
	return 0
}
