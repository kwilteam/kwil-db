package ast

type AlterTSConfigType uint

func (n *AlterTSConfigType) Pos() int {
	return 0
}
