package ast

type QuerySource uint

func (n *QuerySource) Pos() int {
	return 0
}
