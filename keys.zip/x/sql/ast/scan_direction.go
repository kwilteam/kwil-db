package ast

type ScanDirection uint

func (n *ScanDirection) Pos() int {
	return 0
}
