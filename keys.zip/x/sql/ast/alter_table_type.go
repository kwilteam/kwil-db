package ast

type AlterTableType_PG uint

func (n *AlterTableType_PG) Pos() int {
	return 0
}
