package ast

type TableLikeOption uint

func (n *TableLikeOption) Pos() int {
	return 0
}
