package ast

type A_Star struct {
}

func (n *A_Star) Pos() int {
	return 0
}
