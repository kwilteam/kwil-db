package ast

type TransactionStmtKind uint

func (n *TransactionStmtKind) Pos() int {
	return 0
}
