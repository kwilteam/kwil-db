package ast

type VariableSetKind uint

func (n *VariableSetKind) Pos() int {
	return 0
}
