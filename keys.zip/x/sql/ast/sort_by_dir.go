package ast

type SortByDir uint

func (n *SortByDir) Pos() int {
	return 0
}
