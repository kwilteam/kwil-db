package ast

type vartag_external uint

func (n *vartag_external) Pos() int {
	return 0
}
