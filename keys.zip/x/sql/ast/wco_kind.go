package ast

type WCOKind uint

func (n *WCOKind) Pos() int {
	return 0
}
