package ast

type SetOpCmd uint

func (n *SetOpCmd) Pos() int {
	return 0
}
