package flow

import (
	"context"
	"kwil/x/rx"
	"kwil/x/syncx"
	"kwil/x/utils"
)

type SigOnce func(error)

type reason uint32

var subError = reason(1)
var subClosed = reason(2)
var pubError = reason(3)
var pubClosed = reason(4)
var flowCancel = reason(5)

type request[T any] utils.Tuple[context.Context, Result[T]]

func newEmitter[T any](buffer int) *emitter[T] {
	return &emitter[T]{
		queue: syncx.NewChanBuffered[*request[T]](buffer),
		ev:    make(chan rx.Void),
	}
}

type emitter[T any] struct {
	queue syncx.Chan[*request[T]] // queue for event loop
	ev    chan rx.Void            // event loop done chan
}

func (e *emitter[T]) Close() {
	e.queue.Close()
	<-e.ev
}

func (e *emitter[T]) Send(ctx context.Context, item T) error {
	return e._send(ctx, SuccessResult(item))
}

func (e *emitter[T]) SendError(err error) error {
	return e._send(context.Background(), FailureResult[T](err))
}

func (e *emitter[T]) _send(ctx context.Context, item *Result[T]) (err error) {
	ok, err := e.queue.TryWrite(ctx, &request[T]{ctx, *item})
	if err != nil {
		return err
	}

	if !ok {
		return ErrEmitterClosed
	}

	return nil
}

func (e *emitter[T]) run(args *run_args[T]) {
	go func(e *emitter[T], args *run_args[T]) {
		args.sig = make(chan error) // callback from sub onNext when done processing an item
		for {
			done, err := e.handle(args)
			if done == 0 {
				continue
			}

			e.cleanUp(done, err, args)

			break
		}
	}(e, args)
}

func (e *emitter[T]) handle(args *run_args[T]) (reason, error) {
	select {
	case <-e.queue.DoneCh():
		return pubClosed, nil

	case <-args.subDone:
		return subClosed, nil

	case <-args.ctx.Done():
		return flowCancel, nil

	case err := <-args.sig:
		if err != nil {
			return subError, err
		}

		return e.handleSig(args)
	}
}

func (e *emitter[T]) handleSig(args *run_args[T]) (reason, error) {
	select {
	case tpl, ok := <-e.queue.Read():
		if !ok {
			return pubClosed, nil
		}

		item := tpl.Second
		if item.IsError() {
			return pubError, item.GetError()
		}

		args.sub.OnNext(tpl.First, item.Get(), func(err error) { args.sig <- err })

		return reason(0), nil

	case <-e.queue.DoneCh():
		return pubClosed, nil

	case <-args.subDone:
		return subClosed, nil

	case <-args.ctx.Done():
		return flowCancel, nil
	}
}

func (e *emitter[T]) cleanUp(done reason, err error, args *run_args[T]) {
	e.queue.Close()

	if done != subClosed && done != subError {
		if err != nil { // implicitly pub error
			args.sub.OnError(err)
		} else if done == flowCancel || done == pubClosed {
			args.sub.OnComplete()
		}
		<-args.subDone // wait for sub to clean up
	}

	close(e.ev)

	if done != flowCancel {
		args.notifyFlow(err)
	}
}

type run_args[T any] struct {
	sub        Sub[T]
	subDone    <-chan rx.Void
	ctx        context.Context // overall flow context
	notifyFlow SigOnce         // fn to tell outer flow of an error or overall completion
	sig        chan error
}
