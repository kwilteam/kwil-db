package flow

import "context"

type Sub[T any] interface {
	OnNext(context.Context, T, SigOnce)
	OnError(error)
	OnComplete()

	OnSubscribe(s Subscription)
}
