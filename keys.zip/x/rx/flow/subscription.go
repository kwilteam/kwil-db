package flow

type Subscription interface {
	Cancel()
	Connect()
}
