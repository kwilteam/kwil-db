package flow

import (
	"kwil/x/rx"
	"sync/atomic"
	"unsafe"
)

var closed_channel unsafe.Pointer
var empty_fn unsafe.Pointer

func init() {
	ch := make(chan rx.Void)
	close(ch)
	closed_channel = unsafe.Pointer(&ch)
	fn := func() {}
	empty_fn = unsafe.Pointer(&fn)
}

type emitter_subscription struct {
	done    chan rx.Void
	connect func()
}

func (s *emitter_subscription) Cancel() {
	ptr := unsafe.Pointer(&s.done)
	done := atomic.SwapPointer(&ptr, closed_channel)
	if done != closed_channel {
		close(*(*chan rx.Void)(done))
	}
}

func (s *emitter_subscription) Connect() {
	ptr := unsafe.Pointer(&s.connect)
	fn := atomic.SwapPointer(&ptr, empty_fn)
	if fn != empty_fn {
		(*(*func())(fn))()
	}
}
