package flow

type Pub[T any] interface {
	Subscribe(sub Sub[T])
}
