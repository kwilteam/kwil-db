package flow

import (
	"kwil/x/rx"
)

type SubscribableEmitter[T any] interface {
	OnConnect() rx.Task[Emitter[T]]
	Subscribe(sub Sub[T])
}
