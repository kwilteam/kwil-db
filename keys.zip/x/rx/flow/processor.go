package flow

//import "context
//
//type processor[T, R any] struct {
//	emitter *subscribable_emitter[R]
//	smt     func(T, func(R, error))
//	buffer  int
//}
//
//func newMap[T, R any](buffer int, smt func(T, func(R, error))) *processor[T, R] {
//	return &processor[T, R]{smt: smt, buffer: buffer}
//}
//
//func (m *processor[T, R]) Via(pub Pub[T], ctx context.Context, buffer int, notifyFlow SigOnce) {
//	em := NewSubscribableEmitter[T](ctx, buffer, notifyFlow)
//	p := processor[R]{emitter: em, smt: smt}
//}
//
//func (m *processor[T, R]) Subscribe(sub Sub[T]) {
//
//}
