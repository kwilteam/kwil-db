package flow

import (
	"context"
	"errors"
)

var ErrEmitterClosed = errors.New("emitter is closed")
var ErrEmitterAlreadySubscribed = errors.New("emitter already subscribed")

type Emitter[T any] interface {
	// Send sends a value to the Sub.
	Send(ctx context.Context, item T) error

	// SendError will propagate the error and close down
	// the emitter.
	SendError(err error) error

	// Close will signal the sub and publisher of the
	// emitter to stop processing and close down cleanly.
	Close()
}
