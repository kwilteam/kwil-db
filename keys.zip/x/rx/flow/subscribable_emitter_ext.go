package flow

import (
	"context"
	"kwil/x/rx"
	"sync/atomic"
	"unsafe"
)

type subscribable_emitter[T any] struct {
	emitter    rx.Task[Emitter[T]]
	ctx        context.Context
	buffer     int
	notifyFlow SigOnce
	sub        Sub[T]
}

func NewSubscribableEmitter[T any](ctx context.Context, buffer int, notifyFlow SigOnce) SubscribableEmitter[T] {
	task := rx.NewTask[Emitter[T]]()
	return &subscribable_emitter[T]{task, ctx, buffer, notifyFlow, nil}
}

func (e *subscribable_emitter[T]) OnConnect() rx.Task[Emitter[T]] {
	return e.emitter
}

func (e *subscribable_emitter[T]) Subscribe(sub Sub[T]) {
	ptr := unsafe.Pointer(&e.sub)
	if !atomic.CompareAndSwapPointer(&ptr, nil, unsafe.Pointer(&sub)) {
		sub.OnError(ErrEmitterAlreadySubscribed)
		return
	}

	done := make(chan rx.Void)
	s := &emitter_subscription{done: done, connect: func() {
		em := newEmitter[T](e.buffer)
		e.emitter.Complete(em)
		em.run(&run_args[T]{
			sub:        sub,
			subDone:    done,
			notifyFlow: e.notifyFlow,
		})
	}}

	sub.OnSubscribe(s)
}
